import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { trpc } from "@/lib/trpc";
import { Loader2 } from "lucide-react";

const NINNA_PHOTO = "https://d2xsxph8kpxj0f.cloudfront.net/310519663374918860/bisbNXnGgW3LbCjoFp38Wa/ninna_profile_b8ddc440.jpeg";

export default function Landing() {
  const [, setLocation] = useLocation();
  const { user } = useAuth();
  const [name, setName] = useState("");
  const [language, setLanguage] = useState<"cs" | "en">("cs");
  const [isLoading, setIsLoading] = useState(false);

  // Redirect if already authenticated
  useEffect(() => {
    if (user) {
      setLocation("/chat");
    }
  }, [user, setLocation]);

  const createConversationMutation = trpc.chat.createConversation.useMutation();
  const updateLanguageMutation = trpc.chat.updateLanguage.useMutation();

  const handleEnter = async () => {
    if (!name.trim()) return;

    setIsLoading(true);
    try {
      // Update language preference
      await updateLanguageMutation.mutateAsync({ language });

      // Create initial conversation
      const conversation = await createConversationMutation.mutateAsync({
        title: "New Chat",
      });

      // Redirect to chat
      setLocation(`/chat/${conversation.id}`);
    } catch (error) {
      console.error("Error:", error);
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-background flex items-center justify-center p-4 overflow-hidden relative">
      {/* Animated gradient background */}
      <div className="absolute top-0 left-0 w-full h-full">
        <div className="absolute top-0 left-1/4 w-96 h-96 bg-pink-500/20 rounded-full blur-3xl animate-float" />
        <div className="absolute bottom-0 right-1/4 w-96 h-96 bg-purple-500/20 rounded-full blur-3xl animate-float" style={{ animationDelay: "2s" }} />
      </div>

      {/* Main content */}
      <div className="relative z-10 w-full max-w-md">
        <div className="glass rounded-3xl overflow-hidden">
          {/* Photo section */}
          <div className="relative h-96 overflow-hidden">
            <img
              src={NINNA_PHOTO}
              alt="Ninna Ray"
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black via-black/30 to-transparent pointer-events-none" />

            {/* Status indicator */}
            <div className="absolute top-6 right-6 flex items-center gap-2">
              <span className="w-3 h-3 bg-green-400 rounded-full animate-pulse-glow" />
              <p className="text-green-400 text-xs font-bold uppercase tracking-wider">
                {language === "cs" ? "Online" : "Online"}
              </p>
            </div>

            {/* Title */}
            <div className="absolute bottom-6 left-6 right-6">
              <h1 className="text-4xl font-bold text-white tracking-tight font-playfair italic">
                Ninna_Ray🍒
              </h1>
            </div>
          </div>

          {/* Form section */}
          <div className="pt-8 pb-10 px-8 space-y-6">
            {/* Language selector */}
            <div className="flex justify-center gap-3">
              <button
                onClick={() => setLanguage("cs")}
                className={`px-4 py-2 rounded-full text-xs font-bold uppercase transition-all duration-300 ${
                  language === "cs"
                    ? "bg-gradient-pink-purple text-white glow-pink-purple"
                    : "bg-white/10 text-white/60 hover:bg-white/15"
                }`}
              >
                Čeština
              </button>
              <button
                onClick={() => setLanguage("en")}
                className={`px-4 py-2 rounded-full text-xs font-bold uppercase transition-all duration-300 ${
                  language === "en"
                    ? "bg-gradient-pink-purple text-white glow-pink-purple"
                    : "bg-white/10 text-white/60 hover:bg-white/15"
                }`}
              >
                English
              </button>
            </div>

            {/* Name input */}
            <div className="space-y-3">
              <label className="text-xs font-bold text-white/60 uppercase tracking-widest ml-1">
                {language === "cs" ? "Tvé jméno" : "Your Name"}
              </label>
              <Input
                placeholder={
                  language === "cs"
                    ? "Jak ti mám říkat?"
                    : "How should I call you?"
                }
                value={name}
                onChange={(e) => setName(e.target.value)}
                onKeyPress={(e) => {
                  if (e.key === "Enter" && !isLoading) {
                    handleEnter();
                  }
                }}
                disabled={isLoading}
                className="h-14 bg-white/10 border-white/20 text-white rounded-2xl focus:border-pink-500/50 focus:ring-pink-500/30 transition-all text-base px-6 placeholder:text-white/40"
              />
            </div>

            {/* Enter button */}
            <Button
              onClick={handleEnter}
              disabled={!name.trim() || isLoading}
              className="w-full bg-gradient-pink-purple hover:opacity-90 text-white font-bold h-14 rounded-2xl text-base shadow-xl glow-pink-purple transition-all active:scale-95 border-none disabled:opacity-50"
            >
              {isLoading ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  {language === "cs" ? "Připojuji..." : "Connecting..."}
                </>
              ) : language === "cs" ? (
                "Vstoupit do chatu"
              ) : (
                "Enter Private Chat"
              )}
            </Button>

            {/* Age disclaimer */}
            <p className="text-center text-xs text-white/40 uppercase tracking-widest font-medium">
              {language === "cs"
                ? "Vstupem potvrzuješ věk 18+"
                : "Must be 18+ to enter"}
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
