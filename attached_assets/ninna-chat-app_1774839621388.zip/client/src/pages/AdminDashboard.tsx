import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from "recharts";
import { MessageCircle, Users, TrendingUp, Zap, Settings } from "lucide-react";

export default function AdminDashboard() {
  const [selectedLeadId, setSelectedLeadId] = useState<string | null>(null);
  const [selectedState, setSelectedState] = useState<string | undefined>();

  // Fetch data
  const dashboardQuery = trpc.admin.getDashboardSummary.useQuery();
  const leadsQuery = trpc.admin.getLeads.useQuery({
    state: selectedState as any,
    limit: 20,
  });
  const analyticsQuery = trpc.admin.getAnalytics.useQuery({});
  const agentStatusQuery = trpc.admin.getAgentStatus.useQuery();
  const pendingActionsQuery = trpc.admin.getPendingActions.useQuery();
  const conversationQuery = trpc.admin.getConversation.useQuery(
    { leadId: selectedLeadId || "" },
    { enabled: !!selectedLeadId }
  );
  const recommendationsQuery = trpc.admin.getRecommendations.useQuery(
    { leadId: selectedLeadId || "" },
    { enabled: !!selectedLeadId }
  );

  const executeRecommendationMutation = trpc.admin.executeRecommendation.useMutation();

  const handleExecuteRecommendation = async (recId: string, leadId: string, platform: string, content: string) => {
    try {
      await executeRecommendationMutation.mutateAsync({
        recommendationId: recId,
        leadId,
        platform,
        content,
      });
    } catch (error) {
      console.error("Failed to execute recommendation:", error);
    }
  };

  const dashboard = dashboardQuery.data;
  const leads = leadsQuery.data?.leads || [];
  const analytics = analyticsQuery.data;
  const agentStatus = agentStatusQuery.data;
  const pendingActions = pendingActionsQuery.data;
  const conversation = conversationQuery.data;
  const recommendations = recommendationsQuery.data || [];

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-white mb-2">Autonomous Agency Dashboard</h1>
          <p className="text-slate-400">Real-time lead management and AI-powered recommendations</p>
        </div>

        {/* Status Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
          <Card className="bg-slate-800/50 border-slate-700 p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-slate-400 text-sm">Active Conversations</p>
                <p className="text-3xl font-bold text-white">{dashboard?.summary.activeConversations}</p>
              </div>
              <MessageCircle className="w-8 h-8 text-blue-400" />
            </div>
          </Card>

          <Card className="bg-slate-800/50 border-slate-700 p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-slate-400 text-sm">Pending Actions</p>
                <p className="text-3xl font-bold text-white">{dashboard?.summary.pendingActions}</p>
              </div>
              <Zap className="w-8 h-8 text-yellow-400" />
            </div>
          </Card>

          <Card className="bg-slate-800/50 border-slate-700 p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-slate-400 text-sm">Conversion Rate</p>
                <p className="text-3xl font-bold text-white">{dashboard?.summary.conversionRate}%</p>
              </div>
              <TrendingUp className="w-8 h-8 text-green-400" />
            </div>
          </Card>

          <Card className="bg-slate-800/50 border-slate-700 p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-slate-400 text-sm">Hot Leads</p>
                <p className="text-3xl font-bold text-white">{dashboard?.summary.hotLeads}</p>
              </div>
              <Users className="w-8 h-8 text-pink-400" />
            </div>
          </Card>
        </div>

        {/* Main Content */}
        <Tabs defaultValue="leads" className="w-full">
          <TabsList className="grid w-full grid-cols-4 bg-slate-800 border border-slate-700">
            <TabsTrigger value="leads">Leads</TabsTrigger>
            <TabsTrigger value="actions">Pending Actions</TabsTrigger>
            <TabsTrigger value="analytics">Analytics</TabsTrigger>
            <TabsTrigger value="agent">Agent Status</TabsTrigger>
          </TabsList>

          {/* Leads Tab */}
          <TabsContent value="leads" className="space-y-4">
            <div className="flex gap-2 mb-4">
              {["cold", "warm", "hot", "monetized"].map((state) => (
                <Button
                  key={state}
                  variant={selectedState === state ? "default" : "outline"}
                  onClick={() => setSelectedState(selectedState === state ? undefined : state)}
                  className="capitalize"
                >
                  {state}
                </Button>
              ))}
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {/* Leads List */}
              <div className="lg:col-span-1">
                <Card className="bg-slate-800/50 border-slate-700 max-h-96 overflow-y-auto">
                  {leads.map((lead: any) => (
                    <div
                      key={lead.id}
                      onClick={() => setSelectedLeadId(lead.id)}
                      className={`p-4 border-b border-slate-700 cursor-pointer hover:bg-slate-700/50 transition ${
                        selectedLeadId === lead.id ? "bg-slate-700/50" : ""
                      }`}
                    >
                      <div className="flex justify-between items-start mb-2">
                        <div>
                          <p className="font-semibold text-white">{lead.username}</p>
                          <p className="text-xs text-slate-400">{lead.platform}</p>
                        </div>
                        <Badge variant="outline" className="capitalize">
                          {lead.state}
                        </Badge>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-sm text-slate-400">Score: {lead.interestScore}</span>
                        <span className="text-xs text-slate-500">{lead.messageCount} msgs</span>
                      </div>
                    </div>
                  ))}
                </Card>
              </div>

              {/* Conversation & Recommendations */}
              <div className="lg:col-span-2 space-y-4">
                {selectedLeadId && conversation ? (
                  <>
                    {/* Conversation */}
                    <Card className="bg-slate-800/50 border-slate-700 p-4">
                      <h3 className="text-lg font-semibold text-white mb-4">Conversation</h3>
                      <div className="space-y-3 max-h-48 overflow-y-auto">
                        {conversation.messages.map((msg: any) => (
                          <div
                            key={msg.id}
                            className={`p-3 rounded-lg ${
                              msg.direction === "incoming"
                                ? "bg-slate-700/50 text-slate-100"
                                : "bg-pink-500/20 text-pink-100"
                            }`}
                          >
                            <p className="text-sm">{msg.content}</p>
                            <p className="text-xs text-slate-400 mt-1">
                              {new Date(msg.timestamp).toLocaleTimeString()}
                            </p>
                          </div>
                        ))}
                      </div>
                    </Card>

                    {/* Recommendations */}
                    <Card className="bg-slate-800/50 border-slate-700 p-4">
                      <h3 className="text-lg font-semibold text-white mb-4">AI Recommendations</h3>
                      <div className="space-y-3">
                        {recommendations.map((rec: any) => (
                          <div key={rec.id} className="bg-slate-700/50 p-3 rounded-lg">
                            <div className="flex justify-between items-start mb-2">
                              <Badge className="capitalize">{rec.action}</Badge>
                              <span className="text-xs text-slate-400">{rec.priority} priority</span>
                            </div>
                            <p className="text-sm text-slate-300 mb-2">{rec.reasoning}</p>
                            <p className="text-sm text-slate-200 mb-3 italic">
                              "{rec.payload.text || rec.payload.message}"
                            </p>
                            {!rec.executed && (
                              <Button
                                size="sm"
                                onClick={() =>
                                  handleExecuteRecommendation(
                                    rec.id,
                                    selectedLeadId,
                                    conversation.platform,
                                    rec.payload.text || rec.payload.message
                                  )
                                }
                                className="w-full"
                              >
                                Execute
                              </Button>
                            )}
                          </div>
                        ))}
                      </div>
                    </Card>
                  </>
                ) : (
                  <Card className="bg-slate-800/50 border-slate-700 p-8 text-center">
                    <p className="text-slate-400">Select a lead to view conversation and recommendations</p>
                  </Card>
                )}
              </div>
            </div>
          </TabsContent>

          {/* Pending Actions Tab */}
          <TabsContent value="actions">
            <Card className="bg-slate-800/50 border-slate-700 p-6">
              <div className="space-y-4">
                {pendingActions?.actions.map((action: any) => (
                  <div key={action.id} className="bg-slate-700/50 p-4 rounded-lg">
                    <div className="flex justify-between items-start mb-3">
                      <div>
                        <p className="font-semibold text-white">{action.leadName}</p>
                        <p className="text-sm text-slate-400">{action.platform}</p>
                      </div>
                      <Badge className={action.priority === "high" ? "bg-red-500" : "bg-yellow-500"}>
                        {action.priority}
                      </Badge>
                    </div>
                    <p className="text-slate-300 mb-3">{action.message}</p>
                    <p className="text-sm text-slate-200 mb-3 italic">"{action.suggestedContent}"</p>
                    <div className="flex gap-2">
                      <Button size="sm" className="flex-1">
                        Execute
                      </Button>
                      <Button size="sm" variant="outline" className="flex-1">
                        Review
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </Card>
          </TabsContent>

          {/* Analytics Tab */}
          <TabsContent value="analytics">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Summary Stats */}
              <Card className="bg-slate-800/50 border-slate-700 p-6">
                <h3 className="text-lg font-semibold text-white mb-4">Lead Summary</h3>
                <div className="space-y-3">
                  <div className="flex justify-between">
                    <span className="text-slate-400">Total Leads</span>
                    <span className="text-white font-semibold">{analytics?.summary.totalLeads}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">Cold</span>
                    <span className="text-blue-400">{analytics?.summary.coldLeads}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">Warm</span>
                    <span className="text-yellow-400">{analytics?.summary.warmLeads}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">Hot</span>
                    <span className="text-orange-400">{analytics?.summary.hotLeads}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">Monetized</span>
                    <span className="text-green-400">{analytics?.summary.monetizedLeads}</span>
                  </div>
                </div>
              </Card>

              {/* Engagement Stats */}
              <Card className="bg-slate-800/50 border-slate-700 p-6">
                <h3 className="text-lg font-semibold text-white mb-4">Engagement</h3>
                <div className="space-y-3">
                  <div className="flex justify-between">
                    <span className="text-slate-400">Conversion Rate</span>
                    <span className="text-white font-semibold">{analytics?.engagement.conversionRate}%</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">Messages Sent Today</span>
                    <span className="text-white">{analytics?.engagement.messagesSentToday}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">Messages Received</span>
                    <span className="text-white">{analytics?.engagement.messagesReceivedToday}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">Avg Response Time</span>
                    <span className="text-white">{analytics?.engagement.averageResponseTime}</span>
                  </div>
                </div>
              </Card>

              {/* Platform Breakdown */}
              <Card className="bg-slate-800/50 border-slate-700 p-6 lg:col-span-2">
                <h3 className="text-lg font-semibold text-white mb-4">Platform Performance</h3>
                <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
                  {Object.entries(analytics?.platformBreakdown || {}).map(([platform, data]: any) => (
                    <div key={platform} className="bg-slate-700/50 p-3 rounded-lg text-center">
                      <p className="text-sm text-slate-400 capitalize mb-2">{platform}</p>
                      <p className="text-lg font-bold text-white">{data.leads}</p>
                      <p className="text-xs text-slate-400">leads</p>
                      <p className="text-xs text-green-400 mt-1">{data.conversionRate}% conv</p>
                    </div>
                  ))}
                </div>
              </Card>
            </div>
          </TabsContent>

          {/* Agent Status Tab */}
          <TabsContent value="agent">
            <Card className="bg-slate-800/50 border-slate-700 p-6">
              <div className="space-y-6">
                {/* Status */}
                <div>
                  <h3 className="text-lg font-semibold text-white mb-4">Agent Status</h3>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                    <div className="bg-slate-700/50 p-4 rounded-lg">
                      <p className="text-slate-400 text-sm mb-1">Status</p>
                      <p className="text-white font-semibold capitalize">{agentStatus?.status}</p>
                    </div>
                    <div className="bg-slate-700/50 p-4 rounded-lg">
                      <p className="text-slate-400 text-sm mb-1">Uptime</p>
                      <p className="text-white font-semibold">{agentStatus?.uptime}</p>
                    </div>
                    <div className="bg-slate-700/50 p-4 rounded-lg">
                      <p className="text-slate-400 text-sm mb-1">Decisions Today</p>
                      <p className="text-white font-semibold">{agentStatus?.decisionsToday}</p>
                    </div>
                    <div className="bg-slate-700/50 p-4 rounded-lg">
                      <p className="text-slate-400 text-sm mb-1">Success Rate</p>
                      <p className="text-green-400 font-semibold">{(agentStatus?.successRate || 0) * 100}%</p>
                    </div>
                  </div>
                </div>

                {/* Configuration */}
                <div>
                  <h3 className="text-lg font-semibold text-white mb-4">Configuration</h3>
                  <div className="bg-slate-700/50 p-4 rounded-lg space-y-3">
                    <div className="flex justify-between items-center">
                      <span className="text-slate-400">Auto Reply</span>
                      <Badge className={agentStatus?.configuration.autoReply ? "bg-green-500" : "bg-red-500"}>
                        {agentStatus?.configuration.autoReply ? "ON" : "OFF"}
                      </Badge>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-slate-400">Auto Redirect</span>
                      <Badge className={agentStatus?.configuration.autoRedirect ? "bg-green-500" : "bg-red-500"}>
                        {agentStatus?.configuration.autoRedirect ? "ON" : "OFF"}
                      </Badge>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-slate-400">Language</span>
                      <Badge>{agentStatus?.configuration.language}</Badge>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-slate-400">Messages/Day</span>
                      <span className="text-white">
                        {agentStatus?.configuration.currentMessagesPerDay}/{agentStatus?.configuration.maxMessagesPerDay}
                      </span>
                    </div>
                  </div>
                </div>

                {/* Next Actions */}
                <div>
                  <h3 className="text-lg font-semibold text-white mb-4">Next Actions</h3>
                  <div className="space-y-2">
                    {agentStatus?.nextActions.map((action: string, idx: number) => (
                      <div key={idx} className="bg-slate-700/50 p-3 rounded-lg flex items-start gap-3">
                        <span className="text-pink-400 font-bold">{idx + 1}.</span>
                        <span className="text-slate-300">{action}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
