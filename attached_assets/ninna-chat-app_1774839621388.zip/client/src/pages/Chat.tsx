import { useState, useEffect, useRef } from "react";
import { useLocation, useRoute } from "wouter";
import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Loader2, Send, Plus, Trash2, Menu } from "lucide-react";
import { Streamdown } from "streamdown";

export default function Chat() {
  const [, setLocation] = useLocation();
  const [match, params] = useRoute("/chat/:id");
  const { user } = useAuth();

  const conversationId = params?.id ? parseInt(params.id as string) : null;
  const [messageInput, setMessageInput] = useState("");
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Queries
  const conversationsQuery = trpc.chat.getConversations.useQuery();
  const conversationQuery = trpc.chat.getConversation.useQuery(
    { id: conversationId || 0 },
    { enabled: !!conversationId }
  );
  const preferencesQuery = trpc.chat.getPreferences.useQuery();

  // Mutations
  const sendMessageMutation = trpc.chat.sendMessage.useMutation();
  const createConversationMutation = trpc.chat.createConversation.useMutation();
  const deleteConversationMutation = trpc.chat.deleteConversation.useMutation();

  // Auto-scroll to latest message
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [conversationQuery.data?.messages]);

  // Redirect to first conversation if no ID
  useEffect(() => {
    if (!conversationId && conversationsQuery.data?.length) {
      setLocation(`/chat/${conversationsQuery.data[0].id}`);
    }
  }, [conversationsQuery.data, conversationId, setLocation]);

  if (!user) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-white/60" />
      </div>
    );
  }

  const handleSendMessage = async () => {
    if (!messageInput.trim() || !conversationId) return;

    const content = messageInput;
    setMessageInput("");

    try {
      await sendMessageMutation.mutateAsync({
        conversationId,
        content,
      });
      conversationQuery.refetch();
    } catch (error) {
      console.error("Error sending message:", error);
      setMessageInput(content);
    }
  };

  const handleNewConversation = async () => {
    try {
      const conversation = await createConversationMutation.mutateAsync({
        title: "New Chat",
      });
      conversationsQuery.refetch();
      setLocation(`/chat/${conversation.id}`);
      setIsSidebarOpen(false);
    } catch (error) {
      console.error("Error creating conversation:", error);
    }
  };

  const handleDeleteConversation = async (id: number) => {
    try {
      await deleteConversationMutation.mutateAsync({ id });
      conversationsQuery.refetch();
      if (conversationId === id) {
        const remaining = conversationsQuery.data?.filter((c) => c.id !== id);
        if (remaining?.length) {
          setLocation(`/chat/${remaining[0].id}`);
        } else {
          setLocation("/chat");
        }
      }
    } catch (error) {
      console.error("Error deleting conversation:", error);
    }
  };

  const language = preferencesQuery.data?.language || "cs";
  const messages = conversationQuery.data?.messages || [];
  const isLoading = sendMessageMutation.isPending || conversationQuery.isLoading;

  return (
    <div className="min-h-screen bg-background flex">
      {/* Sidebar */}
      <div
        className={`fixed inset-y-0 left-0 z-40 w-64 glass transform transition-transform duration-300 ${
          isSidebarOpen ? "translate-x-0" : "-translate-x-full"
        } md:relative md:translate-x-0`}
      >
        <div className="h-full flex flex-col p-4">
          {/* Header */}
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-lg font-bold text-white font-playfair">
              Ninna
            </h2>
            <button
              onClick={() => setIsSidebarOpen(false)}
              className="md:hidden text-white/60 hover:text-white"
            >
              ✕
            </button>
          </div>

          {/* New chat button */}
          <Button
            onClick={handleNewConversation}
            className="w-full mb-6 bg-gradient-pink-purple hover:opacity-90 text-white rounded-2xl"
          >
            <Plus className="w-4 h-4 mr-2" />
            {language === "cs" ? "Nový chat" : "New Chat"}
          </Button>

          {/* Conversations list */}
          <div className="flex-1 overflow-y-auto space-y-2">
            {conversationsQuery.data?.map((conv) => (
              <div
                key={conv.id}
                className={`group p-3 rounded-xl cursor-pointer transition-all ${
                  conversationId === conv.id
                    ? "bg-white/20 border border-white/30"
                    : "bg-white/5 hover:bg-white/10"
                }`}
                onClick={() => {
                  setLocation(`/chat/${conv.id}`);
                  setIsSidebarOpen(false);
                }}
              >
                <p className="text-sm text-white truncate">{conv.title}</p>
                <p className="text-xs text-white/40 mt-1">
                  {new Date(conv.createdAt).toLocaleDateString(language === "cs" ? "cs-CZ" : "en-US")}
                </p>
              </div>
            ))}
          </div>

          {/* User info */}
          <div className="border-t border-white/10 pt-4 mt-4">
            <p className="text-xs text-white/60 mb-2">
              {language === "cs" ? "Přihlášen jako:" : "Logged in as:"}
            </p>
            <p className="text-sm font-medium text-white truncate">{user.name}</p>
          </div>
        </div>
      </div>

      {/* Main chat area */}
      <div className="flex-1 flex flex-col relative">
        {/* Header */}
        <div className="glass-md border-b border-white/10 p-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <button
              onClick={() => setIsSidebarOpen(true)}
              className="md:hidden text-white/60 hover:text-white"
            >
              <Menu className="w-5 h-5" />
            </button>
            <h1 className="text-xl font-bold text-white font-playfair italic">
              Ninna_Ray🍒
            </h1>
          </div>
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 bg-green-400 rounded-full animate-pulse-glow" />
            <span className="text-xs text-green-400 font-medium">
              {language === "cs" ? "Online" : "Online"}
            </span>
          </div>
        </div>

        {/* Messages area */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          {messages.length === 0 ? (
            <div className="h-full flex items-center justify-center">
              <div className="text-center">
                <p className="text-white/60 text-lg mb-2 font-playfair">
                  {language === "cs"
                    ? "Začni konverzaci"
                    : "Start a conversation"}
                </p>
                <p className="text-white/40 text-sm">
                  {language === "cs"
                    ? "Napiš něco Nině..."
                    : "Say something to Ninna..."}
                </p>
              </div>
            </div>
          ) : (
            messages.map((msg, idx) => (
              <div
                key={idx}
                className={`flex ${msg.role === "user" ? "justify-end" : "justify-start"}`}
              >
                <div
                  className={`max-w-xs lg:max-w-md xl:max-w-lg px-4 py-3 rounded-2xl ${
                    msg.role === "user"
                      ? "bg-gradient-pink-purple text-white rounded-br-none"
                      : "glass-sm text-white rounded-bl-none"
                  }`}
                >
                  <Streamdown>{msg.content}</Streamdown>
                  <p className="text-xs mt-2 opacity-60">
                    {new Date(msg.createdAt).toLocaleTimeString(
                      language === "cs" ? "cs-CZ" : "en-US",
                      { hour: "2-digit", minute: "2-digit" }
                    )}
                  </p>
                </div>
              </div>
            ))
          )}

          {sendMessageMutation.isPending && (
            <div className="flex justify-start">
              <div className="glass-sm px-4 py-3 rounded-2xl rounded-bl-none">
                <div className="flex gap-1">
                  <span className="w-2 h-2 bg-white/60 rounded-full animate-typing" />
                  <span
                    className="w-2 h-2 bg-white/60 rounded-full animate-typing"
                    style={{ animationDelay: "0.2s" }}
                  />
                  <span
                    className="w-2 h-2 bg-white/60 rounded-full animate-typing"
                    style={{ animationDelay: "0.4s" }}
                  />
                </div>
              </div>
            </div>
          )}

          <div ref={messagesEndRef} />
        </div>

        {/* Input area */}
        <div className="glass-md border-t border-white/10 p-4">
          <div className="flex gap-3">
            <Input
              placeholder={
                language === "cs"
                  ? "Napiš zprávu Nině..."
                  : "Message Ninna..."
              }
              value={messageInput}
              onChange={(e) => setMessageInput(e.target.value)}
              onKeyPress={(e) => {
                if (e.key === "Enter" && !isLoading) {
                  handleSendMessage();
                }
              }}
              disabled={isLoading}
              className="flex-1 bg-white/10 border-white/20 text-white rounded-2xl focus:border-pink-500/50 focus:ring-pink-500/30 placeholder:text-white/40"
            />
            <Button
              onClick={handleSendMessage}
              disabled={!messageInput.trim() || isLoading}
              className="bg-gradient-pink-purple hover:opacity-90 text-white rounded-2xl px-4 glow-pink-purple disabled:opacity-50"
            >
              {isLoading ? (
                <Loader2 className="w-4 h-4 animate-spin" />
              ) : (
                <Send className="w-4 h-4" />
              )}
            </Button>
          </div>
        </div>
      </div>

      {/* Overlay for mobile sidebar */}
      {isSidebarOpen && (
        <div
          className="fixed inset-0 bg-black/50 z-30 md:hidden"
          onClick={() => setIsSidebarOpen(false)}
        />
      )}
    </div>
  );
}
