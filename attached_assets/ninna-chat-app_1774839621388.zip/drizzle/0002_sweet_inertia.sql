ALTER TABLE `conversations` MODIFY COLUMN `title` text NOT NULL;--> statement-breakpoint
ALTER TABLE `images` MODIFY COLUMN `mime_type` varchar(50) NOT NULL DEFAULT 'image/jpeg';