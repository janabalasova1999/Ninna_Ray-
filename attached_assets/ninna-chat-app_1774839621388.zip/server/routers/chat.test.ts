import { describe, it, expect, beforeAll, afterAll } from "vitest";
import { appRouter } from "../routers";
import type { TrpcContext } from "../_core/context";

// Mock user for testing
const mockUser = {
  id: 1,
  openId: "test-user",
  email: "test@example.com",
  name: "Test User",
  loginMethod: "manus",
  role: "user" as const,
  createdAt: new Date(),
  updatedAt: new Date(),
  lastSignedIn: new Date(),
};

// Mock context
const createMockContext = (): TrpcContext => ({
  user: mockUser,
  req: {
    protocol: "https",
    headers: {},
  } as TrpcContext["req"],
  res: {} as TrpcContext["res"],
});

describe("Chat Router", () => {
  let caller: ReturnType<typeof appRouter.createCaller>;
  let conversationId: number;

  beforeAll(() => {
    const ctx = createMockContext();
    caller = appRouter.createCaller(ctx);
  });

  it("should create a new conversation", async () => {
    const result = await caller.chat.createConversation({
      title: "Test Conversation",
    });

    expect(result).toBeDefined();
    expect(result.userId).toBe(mockUser.id);
    expect(result.title).toBe("Test Conversation");
    expect(result.id).toBeDefined();

    conversationId = result.id;
  });

  it("should get user conversations", async () => {
    const result = await caller.chat.getConversations();

    expect(Array.isArray(result)).toBe(true);
    expect(result.length).toBeGreaterThan(0);
    expect(result.some((c) => c.id === conversationId)).toBe(true);
  });

  it("should get a specific conversation with messages", async () => {
    const result = await caller.chat.getConversation({
      id: conversationId,
    });

    expect(result).toBeDefined();
    expect(result.id).toBe(conversationId);
    expect(result.userId).toBe(mockUser.id);
    expect(Array.isArray(result.messages)).toBe(true);
  });

  it("should get user preferences", async () => {
    const result = await caller.chat.getPreferences();

    expect(result).toBeDefined();
    expect(result.userId).toBe(mockUser.id);
    expect(["cs", "en"]).toContain(result.language);
  });

  it("should update language preference", async () => {
    const result = await caller.chat.updateLanguage({
      language: "en",
    });

    expect(result).toBeDefined();
    expect(result.language).toBe("en");
  });

  it("should send a message and get AI response", async () => {
    const result = await caller.chat.sendMessage({
      conversationId,
      content: "Hello Ninna!",
    });

    expect(result).toBeDefined();
    expect(result.userMessage).toBeDefined();
    expect(result.userMessage.role).toBe("user");
    expect(result.userMessage.content).toBe("Hello Ninna!");
    expect(result.aiMessage).toBeDefined();
    expect(result.aiMessage.role).toBe("assistant");
    expect(result.aiMessage.content).toBeTruthy();
  }, 15000);

  it("should delete a conversation", async () => {
    // Create a new conversation to delete
    const newConv = await caller.chat.createConversation({
      title: "To Delete",
    });

    const result = await caller.chat.deleteConversation({
      id: newConv.id,
    });

    expect(result.success).toBe(true);

    // Verify it's deleted
    const conversations = await caller.chat.getConversations();
    expect(conversations.some((c) => c.id === newConv.id)).toBe(false);
  });

  afterAll(() => {
    // Cleanup
    if (conversationId) {
      caller.chat.deleteConversation({ id: conversationId }).catch(() => {});
    }
  });
});
