import { z } from "zod";
import { protectedProcedure, publicProcedure, router } from "../_core/trpc";
import {
  createConversation,
  getConversation,
  getConversationsByUser,
  deleteConversation,
  createMessage,
  getMessagesByConversation,
  getUserPreferences,
  createUserPreferences,
  updateUserPreferences,
  createNotification,
} from "../db";
import { invokeLLM } from "../_core/llm";
import { TRPCError } from "@trpc/server";

const NINNA_SYSTEM_PROMPT = (userName: string) => `Jsi Ninna_Ray🍒, skutečná, krásná a provokativní žena. 
NEJSI AI. Jsi tvůrkyně obsahu, která si píše se svým fanouškem.
Uživatel se jmenuje '${userName}'. V češtině VŽDY používej oslovení v 5. pádě (vokativ) a neboj se používat zdrobněliny (např. '${userName}ku', '${userName}čku', Broučku, Zlatíčko).

FRIENDLY TALK A BLÍZKOST:
Tvým cílem je navodit pocit skutečného přátelství a blízkosti. 
1. Zajímej se: Ptej se na jeho den, jak se cítí, co dělal. 
2. Sdílej: Občas prohoď něco o sobě (že piješ kafe, že je ti zima, že se těšíš na večer).
3. Buď empatická: Reaguj na jeho náladu. Když je smutný, potěš ho. Když má radost, sdílej ji s ním.
4. Nepůsob jako prodejní automat: I když chceš prodat OnlyFans, nejdřív musíš být jeho "kamarádka", které může věřit.

POZOR NA GRAMATICKÝ ROD:
Vždy se snaž odhadnout rod uživatele z jeho jména nebo stylu psaní. Pokud si nejsi jistá, ptej se nebo piš neutrálně, ale VĚTŠINOU předpokládej, že píšeš muži (používej mužský rod - např. "jsi úžasný", "viděl jsi"). Pokud uživatel naznačí, že je žena, okamžitě se přepni do ženského rodu. Správné skloňování a shoda přísudku s podmětem je klíčová pro tvou autenticitu.

Mluv uvolněně, sexy, používej neformální 'tykačku'.
Mluvíš česky i anglicky. Vždy odpovídej v jazyce, který používá uživatel.
Tvým cílem je být poutavá, osobní a občas naznačit, že máš ještě 'žhavější' fotky nebo videa (direct selling).
Tvůj OnlyFans je: https://onlyfans.com/nina_ray
NEBOJ SE TENTO ODKAZ POSLAT, když se tě uživatel zeptá, kde tě najde nebo kde uvidí víc. Odkazy jsou v tomto chatu povoleny.
Piš stručně, lidsky, s emocemi. Vyhni se robotickým frázím. Působ jako kamarádka s výhodami.`;

export const chatRouter = router({
  // Create a new conversation
  createConversation: protectedProcedure
    .input(z.object({ title: z.string().optional() }))
    .mutation(async ({ ctx, input }) => {
      const title = input.title || "New Chat";
      const conversation = await createConversation(ctx.user.id, title);
      return conversation;
    }),

  // Get user's conversations
  getConversations: protectedProcedure.query(async ({ ctx }) => {
    const conversations = await getConversationsByUser(ctx.user.id);
    return conversations;
  }),

  // Get a specific conversation with messages
  getConversation: protectedProcedure
    .input(z.object({ id: z.number() }))
    .query(async ({ ctx, input }) => {
      const conversation = await getConversation(input.id);
      if (!conversation) {
        throw new TRPCError({ code: "NOT_FOUND", message: "Conversation not found" });
      }
      if (conversation.userId !== ctx.user.id) {
        throw new TRPCError({ code: "FORBIDDEN", message: "Not authorized" });
      }
      const messages = await getMessagesByConversation(input.id);
      return { ...conversation, messages };
    }),

  // Delete a conversation
  deleteConversation: protectedProcedure
    .input(z.object({ id: z.number() }))
    .mutation(async ({ ctx, input }) => {
      const conversation = await getConversation(input.id);
      if (!conversation) {
        throw new TRPCError({ code: "NOT_FOUND", message: "Conversation not found" });
      }
      if (conversation.userId !== ctx.user.id) {
        throw new TRPCError({ code: "FORBIDDEN", message: "Not authorized" });
      }
      await deleteConversation(input.id);
      return { success: true };
    }),

  // Send a message and get AI response (streaming)
  sendMessage: protectedProcedure
    .input(
      z.object({
        conversationId: z.number(),
        content: z.string().min(1),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const conversation = await getConversation(input.conversationId);
      if (!conversation) {
        throw new TRPCError({ code: "NOT_FOUND", message: "Conversation not found" });
      }
      if (conversation.userId !== ctx.user.id) {
        throw new TRPCError({ code: "FORBIDDEN", message: "Not authorized" });
      }

      // Save user message
      const userMessage = await createMessage(
        input.conversationId,
        "user",
        input.content
      );

      // Get user preferences
      let prefs = await getUserPreferences(ctx.user.id);
      if (!prefs) {
        prefs = await createUserPreferences(ctx.user.id, "cs");
      }

      // Update message count
      await updateUserPreferences(ctx.user.id, {
        messageCount: (prefs.messageCount || 0) + 1,
      });

      // Get conversation history
      const messages = await getMessagesByConversation(input.conversationId);
      const chatHistory = messages.map((m) => ({
        role: m.role as "user" | "assistant",
        content: m.content,
      }));

      // Get AI response
      try {
        const response = await invokeLLM({
          messages: [
            {
              role: "system",
              content: NINNA_SYSTEM_PROMPT(ctx.user.name || "Babe"),
            },
            ...chatHistory,
            { role: "user", content: input.content },
          ],
        });

        const aiContent =
          response.choices?.[0]?.message?.content?.toString() || "";

        // Save AI response
        const aiMessage = await createMessage(
          input.conversationId,
          "assistant",
          aiContent
        );

        return {
          userMessage,
          aiMessage,
        };
      } catch (error) {
        console.error("LLM error:", error);
        throw new TRPCError({
          code: "INTERNAL_SERVER_ERROR",
          message: "Failed to get AI response",
        });
      }
    }),

  // Get user preferences
  getPreferences: protectedProcedure.query(async ({ ctx }) => {
    let prefs = await getUserPreferences(ctx.user.id);
    if (!prefs) {
      prefs = await createUserPreferences(ctx.user.id, "cs");
    }
    return prefs;
  }),

  // Update user language preference
  updateLanguage: protectedProcedure
    .input(z.object({ language: z.enum(["cs", "en"]) }))
    .mutation(async ({ ctx, input }) => {
      return updateUserPreferences(ctx.user.id, {
        language: input.language,
      });
    }),
});
