import { z } from "zod";
import { protectedProcedure, router } from "../_core/trpc";
import { TRPCError } from "@trpc/server";

/**
 * Admin/Agency Router - Autonomous Management System
 * Manages leads, conversations, and AI recommendations across multiple platforms
 */

export const adminRouter = router({
  /**
   * Get all leads with filtering and sorting
   */
  getLeads: protectedProcedure
    .input(
      z.object({
        state: z.enum(["cold", "warm", "hot", "monetized", "churned"]).optional(),
        platform: z.string().optional(),
        sortBy: z.enum(["interestScore", "lastMessageAt", "createdAt"]).default("interestScore"),
        order: z.enum(["asc", "desc"]).default("desc"),
        limit: z.number().default(50),
        offset: z.number().default(0),
      })
    )
    .query(async ({ ctx, input }) => {
      // Mock data - in production, this connects to Supabase
      const leads = [
        {
          id: "lead_1",
          platform: "instagram",
          externalUserId: "user_ig_123",
          username: "john_doe_ig",
          displayName: "John Doe",
          state: "hot",
          interestScore: 85,
          tags: ["interested", "engaged", "ready_to_convert"],
          lastMessageAt: new Date(Date.now() - 1000 * 60 * 5).toISOString(),
          messageCount: 12,
          profileUrl: "https://instagram.com/john_doe_ig",
        },
        {
          id: "lead_2",
          platform: "telegram",
          externalUserId: "user_tg_456",
          username: "jane_smith",
          displayName: "Jane Smith",
          state: "warm",
          interestScore: 65,
          tags: ["interested", "asking_questions"],
          lastMessageAt: new Date(Date.now() - 1000 * 60 * 30).toISOString(),
          messageCount: 8,
          profileUrl: "https://t.me/jane_smith",
        },
        {
          id: "lead_3",
          platform: "facebook",
          externalUserId: "user_fb_789",
          username: "bob_wilson",
          displayName: "Bob Wilson",
          state: "cold",
          interestScore: 35,
          tags: ["new", "curious"],
          lastMessageAt: new Date(Date.now() - 1000 * 60 * 120).toISOString(),
          messageCount: 2,
          profileUrl: "https://facebook.com/bob.wilson",
        },
      ];

      // Apply filters
      let filtered = leads;
      if (input.state) {
        filtered = filtered.filter((l) => l.state === input.state);
      }
      if (input.platform) {
        filtered = filtered.filter((l) => l.platform === input.platform);
      }

      // Apply sorting
      filtered.sort((a, b) => {
        let aVal = a[input.sortBy as keyof typeof a];
        let bVal = b[input.sortBy as keyof typeof b];

        if (typeof aVal === "string") {
          aVal = new Date(aVal).getTime();
          bVal = new Date(bVal as string).getTime();
        }

        const comparison = (aVal as number) - (bVal as number);
        return input.order === "desc" ? -comparison : comparison;
      });

      // Apply pagination
      const paginated = filtered.slice(input.offset, input.offset + input.limit);

      return {
        leads: paginated,
        total: filtered.length,
        offset: input.offset,
        limit: input.limit,
      };
    }),

  /**
   * Get conversation thread with a specific lead
   */
  getConversation: protectedProcedure
    .input(z.object({ leadId: z.string() }))
    .query(async ({ ctx, input }) => {
      // Mock conversation data
      const conversation = {
        id: `conv_${input.leadId}`,
        leadId: input.leadId,
        platform: "instagram",
        messages: [
          {
            id: "msg_1",
            direction: "incoming",
            content: "Ahoj! Jak se máš? 😊",
            timestamp: new Date(Date.now() - 1000 * 60 * 10).toISOString(),
            sender: "john_doe_ig",
          },
          {
            id: "msg_2",
            direction: "outgoing",
            content: "Ahoj! Já se mám skvěle, díky za zprávu! Jak se máš ty? 🍒",
            timestamp: new Date(Date.now() - 1000 * 60 * 9).toISOString(),
            sender: "ninna",
          },
          {
            id: "msg_3",
            direction: "incoming",
            content: "Taky super! Kde tě můžu vidět víc?",
            timestamp: new Date(Date.now() - 1000 * 60 * 5).toISOString(),
            sender: "john_doe_ig",
          },
        ],
        lastMessage: "Kde tě můžu vidět víc?",
        lastMessageAt: new Date(Date.now() - 1000 * 60 * 5).toISOString(),
      };

      return conversation;
    }),

  /**
   * Get AI recommendations for a lead
   */
  getRecommendations: protectedProcedure
    .input(z.object({ leadId: z.string(), limit: z.number().default(5) }))
    .query(async ({ ctx, input }) => {
      // Mock recommendations
      const recommendations = [
        {
          id: "rec_1",
          leadId: input.leadId,
          action: "reply",
          priority: "high",
          payload: {
            text: "Mám pro tebe exkluzivní obsah na OnlyFans! Chceš vidět? 🍒",
            tone: "flirty",
            language: "cs",
          },
          reasoning: "User asked where to see more content. Strong buying intent detected.",
          executed: false,
          suggestedAt: new Date().toISOString(),
        },
        {
          id: "rec_2",
          leadId: input.leadId,
          action: "redirect",
          priority: "medium",
          payload: {
            url: "https://onlyfans.com/ninna_ray",
            message: "Všechny moje nejlepší fotky jsou tam! 💋",
          },
          reasoning: "Lead is in 'hot' state. Time to redirect to OnlyFans.",
          executed: false,
          suggestedAt: new Date().toISOString(),
        },
      ];

      return recommendations;
    }),

  /**
   * Execute a recommendation (send message)
   */
  executeRecommendation: protectedProcedure
    .input(
      z.object({
        recommendationId: z.string(),
        leadId: z.string(),
        platform: z.string(),
        content: z.string(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      // In production: Send via platform API (Instagram, Telegram, etc.)
      // Update recommendation as executed
      // Log analytics

      return {
        success: true,
        messageId: `msg_${Date.now()}`,
        timestamp: new Date().toISOString(),
        platform: input.platform,
      };
    }),

  /**
   * Get analytics and metrics
   */
  getAnalytics: protectedProcedure
    .input(
      z.object({
        platform: z.string().optional(),
        dateFrom: z.string().optional(),
        dateTo: z.string().optional(),
      })
    )
    .query(async ({ ctx, input }) => {
      return {
        summary: {
          totalLeads: 150,
          coldLeads: 80,
          warmLeads: 45,
          hotLeads: 20,
          monetizedLeads: 5,
          churnedLeads: 0,
        },
        engagement: {
          averageInterestScore: 62,
          conversionRate: 3.3,
          messagesSentToday: 45,
          messagesReceivedToday: 38,
          averageResponseTime: "2.5 hours",
        },
        platformBreakdown: {
          instagram: { leads: 60, messages: 120, conversionRate: 5 },
          facebook: { leads: 40, messages: 80, conversionRate: 2.5 },
          telegram: { leads: 30, messages: 70, conversionRate: 4 },
          fansly: { leads: 15, messages: 30, conversionRate: 13 },
          fanvue: { leads: 5, messages: 10, conversionRate: 20 },
        },
        revenue: {
          totalMonetized: 5,
          estimatedMonthlyRevenue: 2500,
          averageLifetimeValue: 500,
        },
      };
    }),

  /**
   * Get content strategy recommendations
   */
  getContentStrategy: protectedProcedure
    .input(
      z.object({
        leadState: z.enum(["cold", "warm", "hot", "monetized"]),
        platform: z.string(),
      })
    )
    .query(async ({ ctx, input }) => {
      const strategies: Record<string, Record<string, unknown>> = {
        cold: {
          contentType: "teasing",
          purpose: "interest",
          tone: "mysterious",
          examples: [
            "Behind-the-scenes content",
            "Lifestyle photos",
            "Mysterious captions",
            "Story teasers",
          ],
          bestPlatforms: ["instagram", "facebook"],
          frequency: "2-3 posts per week",
        },
        warm: {
          contentType: "personal",
          purpose: "engagement",
          tone: "friendly",
          examples: [
            "Personal stories",
            "Q&A sessions",
            "Exclusive previews",
            "Direct messages",
          ],
          bestPlatforms: ["instagram", "telegram"],
          frequency: "Daily interactions",
        },
        hot: {
          contentType: "exclusive",
          purpose: "redirect",
          tone: "direct",
          examples: [
            "OnlyFans teasers",
            "Limited-time offers",
            "Direct OnlyFans links",
            "Exclusive content samples",
          ],
          bestPlatforms: ["telegram", "fansly"],
          frequency: "Multiple daily",
        },
        monetized: {
          contentType: "premium",
          purpose: "upsell",
          tone: "premium",
          examples: [
            "Exclusive content updates",
            "Premium tier promotions",
            "VIP interactions",
            "Custom content offers",
          ],
          bestPlatforms: ["onlyfans"],
          frequency: "Regular updates",
        },
      };

      return strategies[input.leadState] || {};
    }),

  /**
   * Update lead tags and metadata
   */
  updateLeadTags: protectedProcedure
    .input(
      z.object({
        leadId: z.string(),
        tags: z.array(z.string()),
        notes: z.string().optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      // Update in Supabase
      return {
        success: true,
        leadId: input.leadId,
        tags: input.tags,
        updatedAt: new Date().toISOString(),
      };
    }),

  /**
   * Get pending actions for autonomous execution
   */
  getPendingActions: protectedProcedure.query(async ({ ctx }) => {
    const actions = [
      {
        id: "action_1",
        leadId: "lead_1",
        platform: "instagram",
        type: "reply",
        priority: "high",
        leadName: "John Doe",
        message: "User asked where to see more content",
        suggestedContent:
          "Mám pro tebe exkluzivní obsah na OnlyFans! Chceš vidět? 🍒",
        confidence: 0.95,
      },
      {
        id: "action_2",
        leadId: "lead_2",
        platform: "telegram",
        type: "redirect",
        priority: "medium",
        leadName: "Jane Smith",
        message: "Time to move to OnlyFans",
        suggestedContent: "Všechny moje nejlepší fotky jsou na OnlyFans!",
        confidence: 0.85,
      },
      {
        id: "action_3",
        leadId: "lead_3",
        platform: "facebook",
        type: "content",
        priority: "low",
        leadName: "Bob Wilson",
        message: "Send teasing content to warm up",
        suggestedContent: "Behind-the-scenes photo with teasing caption",
        confidence: 0.7,
      },
    ];

    return {
      actions,
      totalPending: actions.length,
      highPriority: actions.filter((a) => a.priority === "high").length,
    };
  }),

  /**
   * Get dashboard summary
   */
  getDashboardSummary: protectedProcedure.query(async ({ ctx }) => {
    return {
      status: "active",
      lastUpdate: new Date().toISOString(),
      autonomyLevel: "high",
      summary: {
        activeConversations: 23,
        pendingActions: 7,
        todayMessages: 83,
        conversionRate: 3.3,
        topPlatform: "instagram",
        hotLeads: 20,
        todayRevenue: 125,
      },
      alerts: [
        {
          type: "high_interest",
          severity: "info",
          message: "5 users with high interest score ready for conversion",
          count: 5,
        },
        {
          type: "stagnant",
          severity: "warning",
          message: "8 conversations inactive for 24h - consider re-engagement",
          count: 8,
        },
        {
          type: "success",
          severity: "success",
          message: "2 new monetized users today!",
          count: 2,
        },
      ],
      recentConversions: [
        {
          leadName: "Maria K.",
          platform: "instagram",
          convertedAt: new Date(Date.now() - 1000 * 60 * 30).toISOString(),
          value: 50,
        },
        {
          leadName: "Alex P.",
          platform: "telegram",
          convertedAt: new Date(Date.now() - 1000 * 60 * 120).toISOString(),
          value: 75,
        },
      ],
    };
  }),

  /**
   * Get autonomous agent status and configuration
   */
  getAgentStatus: protectedProcedure.query(async ({ ctx }) => {
    return {
      status: "running",
      uptime: "48 hours",
      decisionsToday: 127,
      successRate: 0.933,
      configuration: {
        autoReply: true,
        autoRedirect: true,
        autoContent: true,
        language: "cs",
        tone: "flirty",
        maxMessagesPerDay: 500,
        currentMessagesPerDay: 83,
      },
      nextActions: [
        "Process 7 pending recommendations",
        "Send daily content to 15 cold leads",
        "Check conversion metrics",
      ],
    };
  }),
});
