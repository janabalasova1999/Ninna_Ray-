import { describe, expect, it } from "vitest";
import { appRouter } from "../routers";
import type { TrpcContext } from "../_core/context";

type AuthenticatedUser = NonNullable<TrpcContext["user"]>;

function createAuthContext(): TrpcContext {
  const user: AuthenticatedUser = {
    id: 1,
    openId: "admin-user",
    email: "admin@example.com",
    name: "Admin User",
    loginMethod: "manus",
    role: "admin",
    createdAt: new Date(),
    updatedAt: new Date(),
    lastSignedIn: new Date(),
  };

  const ctx: TrpcContext = {
    user,
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {
      clearCookie: () => {},
    } as TrpcContext["res"],
  };

  return ctx;
}

describe("admin router - autonomous agency management", () => {
  it("should get leads with proper structure", async () => {
    const ctx = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.admin.getLeads({
      limit: 10,
      offset: 0,
    });

    expect(result).toHaveProperty("leads");
    expect(result).toHaveProperty("total");
    expect(Array.isArray(result.leads)).toBe(true);
    expect(typeof result.total).toBe("number");
  });

  it("should filter leads by state", async () => {
    const ctx = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.admin.getLeads({
      state: "hot",
      limit: 10,
      offset: 0,
    });

    expect(Array.isArray(result.leads)).toBe(true);
    result.leads.forEach((lead: any) => {
      expect(lead.state).toBe("hot");
    });
  });

  it("should get conversation thread for a lead", async () => {
    const ctx = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.admin.getConversation({
      leadId: "lead_1",
    });

    expect(result).toHaveProperty("id");
    expect(result).toHaveProperty("leadId");
    expect(result).toHaveProperty("messages");
    expect(Array.isArray(result.messages)).toBe(true);
    expect(result.messages.length).toBeGreaterThan(0);
  });

  it("should get AI recommendations for a lead", async () => {
    const ctx = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.admin.getRecommendations({
      leadId: "lead_1",
      limit: 5,
    });

    expect(Array.isArray(result)).toBe(true);
    result.forEach((rec: any) => {
      expect(rec).toHaveProperty("id");
      expect(rec).toHaveProperty("action");
      expect(rec).toHaveProperty("reasoning");
      expect(rec).toHaveProperty("executed");
    });
  });

  it("should execute a recommendation", async () => {
    const ctx = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.admin.executeRecommendation({
      recommendationId: "rec_1",
      leadId: "lead_1",
      platform: "instagram",
      content: "Test message",
    });

    expect(result).toHaveProperty("success");
    expect(result.success).toBe(true);
    expect(result).toHaveProperty("messageId");
    expect(result).toHaveProperty("timestamp");
  });

  it("should get analytics", async () => {
    const ctx = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.admin.getAnalytics({});

    expect(result).toHaveProperty("summary");
    expect(result).toHaveProperty("engagement");
    expect(result).toHaveProperty("platformBreakdown");
    expect(result).toHaveProperty("revenue");

    expect(result.summary).toHaveProperty("totalLeads");
    expect(result.summary).toHaveProperty("coldLeads");
    expect(result.summary).toHaveProperty("hotLeads");
    expect(result.engagement).toHaveProperty("conversionRate");
  });

  it("should get content strategy for different lead states", async () => {
    const ctx = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    const coldStrategy = await caller.admin.getContentStrategy({
      leadState: "cold",
      platform: "instagram",
    });

    expect(coldStrategy).toHaveProperty("contentType");
    expect(coldStrategy.contentType).toBe("teasing");
    expect(coldStrategy).toHaveProperty("examples");

    const hotStrategy = await caller.admin.getContentStrategy({
      leadState: "hot",
      platform: "telegram",
    });

    expect(hotStrategy.contentType).toBe("exclusive");
  });

  it("should get pending actions", async () => {
    const ctx = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.admin.getPendingActions();

    expect(result).toHaveProperty("actions");
    expect(result).toHaveProperty("totalPending");
    expect(Array.isArray(result.actions)).toBe(true);
    expect(typeof result.totalPending).toBe("number");
  });

  it("should get dashboard summary", async () => {
    const ctx = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.admin.getDashboardSummary();

    expect(result).toHaveProperty("status");
    expect(result).toHaveProperty("summary");
    expect(result).toHaveProperty("alerts");
    expect(result).toHaveProperty("recentConversions");

    expect(result.summary).toHaveProperty("activeConversations");
    expect(result.summary).toHaveProperty("pendingActions");
    expect(result.summary).toHaveProperty("conversionRate");
  });

  it("should get agent status", async () => {
    const ctx = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.admin.getAgentStatus();

    expect(result).toHaveProperty("status");
    expect(result.status).toBe("running");
    expect(result).toHaveProperty("configuration");
    expect(result).toHaveProperty("nextActions");

    expect(result.configuration).toHaveProperty("autoReply");
    expect(result.configuration).toHaveProperty("language");
    expect(result.configuration.language).toBe("cs");
  });

  it("should update lead tags", async () => {
    const ctx = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.admin.updateLeadTags({
      leadId: "lead_1",
      tags: ["hot", "ready_to_convert", "vip"],
    });

    expect(result).toHaveProperty("success");
    expect(result.success).toBe(true);
    expect(result).toHaveProperty("tags");
    expect(result.tags).toEqual(["hot", "ready_to_convert", "vip"]);
  });
});
